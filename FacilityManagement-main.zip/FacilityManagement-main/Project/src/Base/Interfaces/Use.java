package Base.Interfaces;

public interface Use {
    public void getInfo();
}
