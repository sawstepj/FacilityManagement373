package Base.Interfaces;

public interface MaintenanceInterface {
    public void getInfo();
}
