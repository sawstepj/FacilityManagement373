package Base.Interfaces;

public interface EmployeeType {
    String type();
}
